from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

app_name = 'shop'

urlpatterns = [
    # Home
    path('', views.home, name='home'),

    # Products
# urls.py
    path('', views.product_list, name='product_list'),
    path('category/<slug:category_slug>/', views.product_list, name='product_list_by_category'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),

    # Cart
    path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
# urls.py

    path('cart/', views.view_cart, name='view_cart'),
    path('cart/update/<int:product_id>/', views.update_cart, name='update_cart'),
    path('cart/remove/<int:product_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/', views.checkout, name='checkout'),

    # Auth
    path(
        'login/',
        auth_views.LoginView.as_view(
            template_name='shop/login.html',
            redirect_authenticated_user=True
        ),
        name='login'
    ),
# urls.py (shop app)
path('logout/', views.custom_logout, name='logout'),
]
