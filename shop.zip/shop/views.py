from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Category
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from decimal import Decimal
from django.db.models import Prefetch

# Home page
def home(request):
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)[:6]
    return render(request, 'shop/home.html', {
        'categories': categories,
        'products': products
    })
def featured_product_list(request):
    categories = Category.objects.all()
    category_products = []

    for category in categories:
        # Get only the first available product for this category
        product = category.products.filter(available=True).first()
        category_products.append({
            'category': category,
            'product': product
        })

    context = {
        'category_products': category_products
    }
    return render(request, 'shop/featured_product_list.html', context)
from django.shortcuts import render
from .models import Category, Product
from django.db.models import Prefetch

def category_product_catalog(request):
    # Prefetch available products for each category
    categories = Category.objects.prefetch_related(
        Prefetch('products', queryset=Product.objects.filter(available=True))
    )

    context = {
        'categories': categories
    }
    return render(request, 'shop/category_product_catalog.html', context)

def category_product_list(request):
    # Prefetch only available products to avoid extra queries
    categories = Category.objects.prefetch_related(
        Prefetch('products', queryset=Product.objects.filter(available=True))
    ).all()

    context = {
        'categories': categories
    }
    return render(request, 'shop/category_product_list.html', context)

# Product list
def product_list(request, category_slug=None):
    """
    Display all products or products filtered by category.
    """
    category = None
    products = Product.objects.filter(available=True)

    if category_slug:
        # Get the category or 404
        category = get_object_or_404(Category, slug=category_slug)
        # Filter products by this category
        products = products.filter(category=category)

    # Get all categories for the category buttons
    categories = Category.objects.all()

    context = {
        'category': category,
        'products': products,
        'categories': categories,
    }
    return render(request, 'shop/product_list.html', context)

# Product detail
def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'shop/product_detail.html', {'product': product})

# Add to cart
@login_required(login_url='shop:login')
def add_to_cart(request, product_id):
    """
    Add a product to the cart stored in session.
    """
    product = get_object_or_404(Product, id=product_id)
    cart = request.session.get('cart', {})

    if str(product_id) in cart:
        # Increment quantity if already in cart
        cart[str(product_id)]['quantity'] += 1
    else:
        cart[str(product_id)] = {'quantity': 1}

    request.session['cart'] = cart
    request.session.modified = True
    return redirect('shop:view_cart')


# View cart
@login_required(login_url='shop:login')
def view_cart(request):
    cart = request.session.get('cart', {})  # {product_id: {'quantity': X}}
    cart_items = []
    total_price = Decimal('0.0')

    for product_id, item_data in cart.items():
        product = get_object_or_404(Product, id=product_id)
        quantity = int(item_data.get('quantity', 1))
        subtotal = product.price * quantity
        total_price += subtotal

        cart_items.append({
            'product': product,
            'quantity': quantity,
            'subtotal': subtotal,
        })

    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }

    return render(request, 'shop/cart.html', context)


# Update cart
@login_required(login_url='shop:login')
def update_cart(request, product_id):
    """
    Update the quantity of a product in the cart.
    """
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        try:
            quantity = int(request.POST.get('quantity', 1))
            if quantity < 1:
                quantity = 1
        except ValueError:
            quantity = 1

        if str(product_id) in cart:
            cart[str(product_id)]['quantity'] = quantity
            request.session['cart'] = cart
            request.session.modified = True

    return redirect('shop:view_cart')


# Remove from cart
@login_required(login_url='shop:login')
def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    if str(product_id) in cart:
        del cart[str(product_id)]
        request.session['cart'] = cart
        request.session.modified = True
    return redirect('shop:view_cart')


# Checkout
@login_required(login_url='shop:login')
def checkout(request):
    cart = request.session.get('cart', {})
    if cart:
        request.session['cart'] = {}
        messages.success(request, "Thank you for your purchase!")
    else:
        messages.info(request, "Your cart is empty.")
    return redirect('shop:product_list')

# Logout
@login_required(login_url='shop:login')
def custom_logout(request):
    if request.method == "POST":
        logout(request)
    return redirect('shop:product_list')
