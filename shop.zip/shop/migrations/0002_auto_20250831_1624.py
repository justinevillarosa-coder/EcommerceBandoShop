from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('shop', '0001_initial'),  # change if your last migration is different
    ]

    operations = [
        migrations.AddField(
            model_name='category',
            name='image',
            field=models.ImageField(upload_to='categories/', blank=True, null=True),
        ),
    ]
